package com.example.facegen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
